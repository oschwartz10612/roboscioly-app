module.exports = {
  google: {
    clientID: '358166904210-hd95k3g5o3p3bs2jaf59f6s2pe1k1j56.apps.googleusercontent.com',
    clientSecret: 'j2MddnNqPvDn8PUi01_oB3RK'
  },
  session: {
    cookieKey: 'sciencerocks'
  },
  mysql: {
    user: "root",
    password: "olsmas10612",
    database: "apps"
  },
  env: {
    port: process.env.PORT
  }
};
